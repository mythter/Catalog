﻿namespace BookCatalog.View
{
    internal interface IMainFormView
    {

    }
}
